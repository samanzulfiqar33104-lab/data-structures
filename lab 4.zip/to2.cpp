#include <iostream>
#include <string>
using namespace std;

struct Profile {
    string name;
    string email;
    int age;
    Profile* next;
};

Profile* head = NULL;

// Create profile
void createProfile() {
    Profile* newProfile = new Profile();
    cout << "Enter Name: ";
    cin >> newProfile->name;
    cout << "Enter Email: ";
    cin >> newProfile->email;
    cout << "Enter Age: ";
    cin >> newProfile->age;

    newProfile->next = head;
    head = newProfile;

    cout << "Profile Created Successfully!\n";
}

// Update profile
void updateProfile() {
    string name;
    cout << "Enter Name to Update: ";
    cin >> name;

    Profile* temp = head;
    while (temp != NULL && temp->name != name)
        temp = temp->next;

    if (temp == NULL) {
        cout << "Profile not found!\n";
        return;
    }

    cout << "Enter New Email: ";
    cin >> temp->email;
    cout << "Enter New Age: ";
    cin >> temp->age;

    cout << "Profile Updated Successfully!\n";
}

// Delete profile
void deleteProfile() {
    string name;
    cout << "Enter Name to Delete: ";
    cin >> name;

    Profile* temp = head;
    Profile* prev = NULL;

    while (temp != NULL && temp->name != name) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Profile not found!\n";
        return;
    }

    if (prev == NULL)
        head = temp->next;
    else
        prev->next = temp->next;

    delete temp;
    cout << "Profile Deleted Successfully!\n";
}

// Search profile
void searchProfile() {
    string name;
    cout << "Enter Name to Search: ";
    cin >> name;

    Profile* temp = head;
    while (temp != NULL) {
        if (temp->name == name) {
            cout << "Profile Found:\n";
            cout << "Name: " << temp->name
                 << "\nEmail: " << temp->email
                 << "\nAge: " << temp->age << endl;
            return;
        }
        temp = temp->next;
    }

    cout << "Profile not found!\n";
}

// View all profiles
void viewProfiles() {
    if (head == NULL) {
        cout << "No profiles available!\n";
        return;
    }

    Profile* temp = head;
    cout << "\n--- All Profiles ---\n";
    while (temp != NULL) {
        cout << "Name: " << temp->name
             << ", Email: " << temp->email
             << ", Age: " << temp->age << endl;
        temp = temp->next;
    }
}

int main() {
    int choice;
    do {
        cout << "\n1. Create Profile";
        cout << "\n2. Update Profile";
        cout << "\n3. Delete Profile";
        cout << "\n4. Search Profile";
        cout << "\n5. View All Profiles";
        cout << "\n6. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: createProfile(); break;
            case 2: updateProfile(); break;
            case 3: deleteProfile(); break;
            case 4: searchProfile(); break;
            case 5: viewProfiles(); break;
            case 6: cout << "Exiting Program...\n"; break;
            default: cout << "Invalid Choice!\n";
        }
    } while (choice != 6);

    return 0;
}
