#include <iostream>
#include <string>
using namespace std;

struct Mobile {
    string brand;
    int units;
    float price;
    Mobile* next;
};

Mobile* head = NULL;

// Add new mobile
void addMobile() {
    Mobile* newMobile = new Mobile();
    cout << "Enter Brand Name: ";
    cin >> newMobile->brand;
    cout << "Enter Units in Stock: ";
    cin >> newMobile->units;
    cout << "Enter Price: ";
    cin >> newMobile->price;

    newMobile->next = head;
    head = newMobile;

    cout << "Mobile Added Successfully!\n";
}

// Delete mobile by brand name
void deleteMobile() {
    if (head == NULL) {
        cout << "Inventory is empty!\n";
        return;
    }

    string brand;
    cout << "Enter Brand Name to Delete: ";
    cin >> brand;

    Mobile* temp = head;
    Mobile* prev = NULL;

    while (temp != NULL && temp->brand != brand) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Mobile not found!\n";
        return;
    }

    if (prev == NULL)
        head = temp->next;
    else
        prev->next = temp->next;

    delete temp;
    cout << "Mobile Deleted Successfully!\n";
}

// Display all mobiles
void displayMobiles() {
    if (head == NULL) {
        cout << "No mobiles in inventory!\n";
        return;
    }

    Mobile* temp = head;
    cout << "\n--- Mobile Inventory ---\n";
    while (temp != NULL) {
        cout << "Brand: " << temp->brand
             << ", Units: " << temp->units
             << ", Price: " << temp->price << endl;
        temp = temp->next;
    }
}

int main() {
    int choice;
    do {
        cout << "\n1. Add Mobile";
        cout << "\n2. Delete Mobile";
        cout << "\n3. Display Mobiles";
        cout << "\n4. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: addMobile(); break;
            case 2: deleteMobile(); break;
            case 3: displayMobiles(); break;
            case 4: cout << "Exiting Program...\n"; break;
            default: cout << "Invalid Choice!\n";
        }
    } while (choice != 4);

    return 0;
}
