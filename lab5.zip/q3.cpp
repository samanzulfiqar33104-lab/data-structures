#include <iostream>
#include <string>
using namespace std;

// Player node structure
struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};

// Add player in sorted order
void addPlayer(Player*& head, string name, int score) {
    Player* newPlayer = new Player;
    newPlayer->name = name;
    newPlayer->score = score;
    newPlayer->next = nullptr;
    newPlayer->prev = nullptr;

    if (!head) {  // Empty list
        head = newPlayer;
        return;
    }

    Player* current = head;
    while (current && current->score < score) {
        current = current->next;
    }

    if (!current) {  // Insert at end
        Player* tail = head;
        while (tail->next) tail = tail->next;
        tail->next = newPlayer;
        newPlayer->prev = tail;
    } else if (current == head) {  // Insert at beginning
        newPlayer->next = head;
        head->prev = newPlayer;
        head = newPlayer;
    } else {  // Insert in middle
        newPlayer->next = current;
        newPlayer->prev = current->prev;
        current->prev->next = newPlayer;
        current->prev = newPlayer;
    }
}

// Delete player by name
void deletePlayer(Player*& head, string name) {
    Player* current = head;
    while (current && current->name != name) {
        current = current->next;
    }
    if (!current) {
        cout << "Player not found.\n";
        return;
    }
    if (current == head) head = head->next;
    if (current->prev) current->prev->next = current->next;
    if (current->next) current->next->prev = current->prev;
    delete current;
    cout << "Player deleted successfully.\n";
}

// Display all players
void displayAll(Player* head) {
    if (!head) {
        cout << "No players in the list.\n";
        return;
    }
    Player* current = head;
    cout << "\nPlayers List:\n";
    while (current) {
        cout << current->name << " - " << current->score << endl;
        current = current->next;
    }
}

// Display players with lowest score
void displayLowest(Player* head) {
    if (!head) return;
    int lowestScore = head->score;
    cout << "\nPlayers with lowest score (" << lowestScore << "):\n";
    Player* current = head;
    while (current && current->score == lowestScore) {
        cout << current->name << " - " << current->score << endl;
        current = current->next;
    }
}

// Display players with a given score
void displaySameScore(Player* head, int score) {
    bool found = false;
    Player* current = head;
    while (current) {
        if (current->score == score) {
            cout << current->name << " - " << current->score << endl;
            found = true;
        }
        current = current->next;
    }
    if (!found) cout << "No player has score " << score << endl;
}

// Display backward from a given player
void displayBackward(Player* head, string name) {
    Player* current = head;
    while (current && current->name != name) current = current->next;
    if (!current) {
        cout << "Player not found.\n";
        return;
    }
    cout << "\nPlayers behind " << name << ":\n";
    while (current->prev) {
        current = current->prev;
        cout << current->name << " - " << current->score << endl;
    }
}

// Main menu
int main() {
    Player* head = nullptr;
    int choice;
    string name;
    int score;

    do {
        cout << "\n1. Add Player\n2. Delete Player\n3. Display All\n4. Display Lowest Score\n5. Display Same Score\n6. Display Backward From Player\n0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore(); // clear newline

        switch (choice) {
            case 1:
                cout << "Enter name: ";
                getline(cin, name);
                cout << "Enter score: ";
                cin >> score;
                addPlayer(head, name, score);
                break;
            case 2:
                cout << "Enter name to delete: ";
                getline(cin, name);
                deletePlayer(head, name);
                break;
            case 3:
                displayAll(head);
                break;
            case 4:
                displayLowest(head);
                break;
            case 5:
                cout << "Enter score to search: ";
                cin >> score;
                displaySameScore(head, score);
                break;
            case 6:
                cout << "Enter player name: ";
                getline(cin, name);
                displayBackward(head, name);
                break;
            case 0:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice.\n";
        }
        cin.ignore(); // clear newline for next loop
    } while (choice != 0);

    return 0;
}
