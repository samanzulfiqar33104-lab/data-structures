#include <iostream>
using namespace std;

struct Player {
    string name;
    int score;
    Player* prev;
    Player* next;
};

Player* head = NULL;

// Insert in sorted order
void addPlayer(string name, int score) {
    Player* newNode = new Player();
    newNode->name = name;
    newNode->score = score;
    newNode->next = newNode->prev = NULL;

    if (head == NULL || score < head->score) {
        newNode->next = head;
        if (head != NULL)
            head->prev = newNode;
        head = newNode;
        return;
    }

    Player* temp = head;
    while (temp->next != NULL && temp->next->score < score)
        temp = temp->next;

    newNode->next = temp->next;
    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
    newNode->prev = temp;
}

// Display forward
void display() {
    Player* temp = head;
    while (temp != NULL) {
        cout << temp->name << " (" << temp->score << ") <-> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

// Delete player
void deletePlayer(string name) {
    Player* temp = head;

    while (temp != NULL && temp->name != name)
        temp = temp->next;

    if (temp == NULL) return;

    if (temp->prev != NULL)
        temp->prev->next = temp->next;
    else
        head = temp->next;

    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    delete temp;
}

// Display same score
void sameScore(int score) {
    Player* temp = head;
    while (temp != NULL) {
        if (temp->score == score)
            cout << temp->name << endl;
        temp = temp->next;
    }
}

int main() {
    addPlayer("Ali", 70);
    addPlayer("Ahmed", 60);
    addPlayer("Sara", 70);
    addPlayer("Zain", 55);

    display();

    cout << "Players with score 70:\n";
    sameScore(70);

    deletePlayer("Ahmed");
    display();
}
