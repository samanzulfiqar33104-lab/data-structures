#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

// Insert at end (for initial input)
void insertEnd(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {
        newNode->prev = NULL;
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}

// Insert at beginning
void addBeginning(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = head;

    if (head != NULL)
        head->prev = newNode;

    head = newNode;
}

// Insert after 45
void addAfter45(int value) {
    Node* temp = head;

    while (temp != NULL && temp->data != 45)
        temp = temp->next;

    if (temp == NULL) {
        cout << "45 not found!\n";
        return;
    }

    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}

// Delete from beginning
void deleteBeginning() {
    if (head == NULL) return;

    Node* temp = head;
    head = head->next;

    if (head != NULL)
        head->prev = NULL;

    delete temp;
}

// Delete after 45
void deleteAfter45() {
    Node* temp = head;

    while (temp != NULL && temp->data != 45)
        temp = temp->next;

    if (temp == NULL || temp->next == NULL) {
        cout << "Deletion not possible\n";
        return;
    }

    Node* del = temp->next;
    temp->next = del->next;

    if (del->next != NULL)
        del->next->prev = temp;

    delete del;
}

// Display
void display() {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " <-> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

int main() {
    int n, value;

    cout << "How many marks? ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> value;
        insertEnd(value);
    }

    display();

    addBeginning(99);
    addAfter45(88);
    deleteBeginning();
    deleteAfter45();

    display();
}
