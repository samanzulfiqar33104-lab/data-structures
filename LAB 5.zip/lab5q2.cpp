#include <iostream>
using namespace std;

struct Node {
    float data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void insert(float value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {
        newNode->prev = NULL;
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}

int main() {
    float rain;

    for (int i = 1; i <= 7; i++) {
        do {
            cout << "Enter rainfall for day " << i << ": ";
            cin >> rain;
        } while (rain < 0);

        insert(rain);
    }

    Node* temp = head;
    float total = 0, highest = head->data, lowest = head->data;
    int count = 0;

    while (temp != NULL) {
        total += temp->data;
        if (temp->data > highest) highest = temp->data;
        if (temp->data < lowest) lowest = temp->data;

        temp = temp->next;
        count++;
    }

    cout << "Total rainfall: " << total << endl;
    cout << "Average rainfall: " << total / count << endl;
    cout << "Highest rainfall: " << highest << endl;
    cout << "Lowest rainfall: " << lowest << endl;

    temp = head;
    for (int i = 1; i < 6 && temp != NULL; i++)
        temp = temp->next;

    if (temp != NULL)
        cout << "Rainfall after 5th node: " << temp->data << endl;
}
