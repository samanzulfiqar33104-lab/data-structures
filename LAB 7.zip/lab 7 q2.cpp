#include <iostream>
using namespace std;

class Inventory {
public:
    int serialNum;
    int manufactYear;
    int lotNum;
    Inventory* next;
};

class Stack {
private:
    Inventory* top;

public:
    Stack() {
        top = NULL;
    }

    void push(int s, int y, int l) {
        Inventory* part = new Inventory();

        part->serialNum = s;
        part->manufactYear = y;
        part->lotNum = l;

        part->next = top;
        top = part;

        cout << "Part added to inventory\n";
    }

    void pop() {
        if (top == NULL) {
            cout << "Inventory Empty\n";
            return;
        }

        Inventory* temp = top;

        cout << "\nRemoved Part Details:\n";
        cout << "Serial Number: " << temp->serialNum << endl;
        cout << "Year: " << temp->manufactYear << endl;
        cout << "Lot Number: " << temp->lotNum << endl;

        top = top->next;
        delete temp;
    }

    void display() {
        Inventory* temp = top;

        cout << "\nRemaining Parts in Inventory:\n";

        while (temp != NULL) {
            cout << "Serial: " << temp->serialNum
                 << " | Year: " << temp->manufactYear
                 << " | Lot: " << temp->lotNum << endl;

            temp = temp->next;
        }
    }
};

int main() {
    Stack s;
    int choice;

    do {
        cout << "\n1. Add Part\n2. Remove Part\n3. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            int serial, year, lot;

            cout << "Enter Serial Number: ";
            cin >> serial;

            cout << "Enter Manufacturing Year: ";
            cin >> year;

            cout << "Enter Lot Number: ";
            cin >> lot;

            s.push(serial, year, lot);
        }

        else if (choice == 2) {
            s.pop();
        }

    } while (choice != 3);

    s.display();

    return 0;
}
