#include <iostream>
using namespace std;

class Book {
public:
    string title;
    float price;
    int edition;
    int pages;
    Book* next;
};

class Stack {
private:
    Book* top;

public:
    Stack() {
        top = NULL;
    }

    void push(string t, float p, int e, int pg) {
        Book* newBook = new Book();
        newBook->title = t;
        newBook->price = p;
        newBook->edition = e;
        newBook->pages = pg;

        newBook->next = top;
        top = newBook;

        cout << "Book pushed: " << t << endl;
    }

    void pop() {
        if (top == NULL) {
            cout << "Stack Underflow\n";
            return;
        }

        Book* temp = top;
        cout << "Popped Book: " << top->title << endl;
        top = top->next;
        delete temp;
    }

    void peek() {
        if (top == NULL) {
            cout << "Stack is empty\n";
        } else {
            cout << "\nTop Book:\n";
            cout << "Title: " << top->title << endl;
            cout << "Price: " << top->price << endl;
            cout << "Edition: " << top->edition << endl;
            cout << "Pages: " << top->pages << endl;
        }
    }

    void display() {
        Book* temp = top;
        cout << "\nRemaining Books in Stack:\n";

        while (temp != NULL) {
            cout << "Title: " << temp->title
                 << " | Price: " << temp->price
                 << " | Edition: " << temp->edition
                 << " | Pages: " << temp->pages << endl;

            temp = temp->next;
        }
    }
};

int main() {
    Stack s;

    s.push("C++ Programming", 500, 3, 600);
    s.push("Data Structures", 650, 2, 550);
    s.push("Operating Systems", 700, 4, 800);
    s.push("Computer Networks", 450, 1, 400);
    s.push("Database Systems", 550, 5, 650);

    s.peek();

    s.pop();
    s.pop();

    s.display();

    return 0;
}
