#include <iostream>
#include <stack>
#include <queue>
using namespace std;

queue<int> road;
stack<int> garage;

void On_road(int id) {
    road.push(id);
}

void Enter_garage() {
    if (road.empty()) {
        cout << "No truck on road\n";
        return;
    }
    int id = road.front();
    road.pop();
    garage.push(id);
    cout << "Truck " << id << " entered garage\n";
}

void Exit_garage(int id) {
    if (garage.empty()) {
        cout << "Garage empty\n";
        return;
    }

    if (garage.top() != id) {
        cout << "Truck is not near garage door\n";
    } else {
        cout << "Truck " << id << " exited garage\n";
        garage.pop();
    }
}

void Show_trucks() {
    cout << "Garage (top to bottom): ";
    stack<int> temp = garage;
    while (!temp.empty()) {
        cout << temp.top() << " ";
        temp.pop();
    }

    cout << "\nRoad (front to rear): ";
    queue<int> temp2 = road;
    while (!temp2.empty()) {
        cout << temp2.front() << " ";
        temp2.pop();
    }
    cout << endl;
}

int main() {
    On_road(1);
    On_road(2);
    On_road(3);

    Enter_garage();
    Enter_garage();

    Show_trucks();

    Exit_garage(1); // error
    Exit_garage(2); // correct

    Show_trucks();

    return 0;
}
