#include <iostream>
using namespace std;

struct Applicant {
    int id;
    float height, weight;
    int eyesight;
    string status;
    Applicant* next;
    Applicant* prev;
};

class Queue {
private:
    Applicant* front;
    Applicant* rear;

public:
    Queue() {
        front = rear = NULL;
    }

    bool isEmpty() {
        return front == NULL;
    }

    // Enqueue
    void enqueue(int id, float h, float w, int eye, string status) {
        Applicant* temp = new Applicant;
        temp->id = id;
        temp->height = h;
        temp->weight = w;
        temp->eyesight = eye;
        temp->status = status;
        temp->next = NULL;
        temp->prev = NULL;

        if (rear == NULL) {
            front = rear = temp;
        } else {
            rear->next = temp;
            temp->prev = rear;
            rear = temp;
        }
    }

    // Dequeue (remove from front)
    void dequeue() {
        if (isEmpty()) {
            cout << "Queue Empty\n";
            return;
        }

        Applicant* temp = front;
        cout << "Removed Applicant ID: " << temp->id << endl;

        front = front->next;
        if (front != NULL)
            front->prev = NULL;
        else
            rear = NULL;

        delete temp;
    }

    // Remove 2nd position person
    void removeSecond() {
        if (front == NULL || front->next == NULL) {
            cout << "Not enough applicants\n";
            return;
        }

        Applicant* temp = front->next;

        cout << "Applicant ID " << temp->id << " left the line\n";

        front->next = temp->next;

        if (temp->next != NULL)
            temp->next->prev = front;
        else
            rear = front;

        delete temp;
    }

    // Display queue
    void display() {
        Applicant* temp = front;
        while (temp != NULL) {
            cout << temp->id << " -> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }
};

int main() {
    Queue q;

    // Adding 7 applicants
    q.enqueue(1, 5.5, 60, 1, "Pending");
    q.enqueue(2, 5.6, 62, 1, "Pending");
    q.enqueue(3, 5.7, 65, 1, "Pending");
    q.enqueue(4, 5.8, 68, 1, "Pending");
    q.enqueue(5, 5.9, 70, 1, "Pending");
    q.enqueue(6, 6.0, 75, 1, "Pending");
    q.enqueue(7, 6.1, 80, 1, "Pending");

    cout << "Initial Queue:\n";
    q.display();

    // Remove 2nd applicant
    q.removeSecond();

    cout << "After removing 2nd applicant:\n";
    q.display();

    // First person gives test (dequeue)
    q.dequeue();

    cout << "After dequeue:\n";
    q.display();

    return 0;
}
