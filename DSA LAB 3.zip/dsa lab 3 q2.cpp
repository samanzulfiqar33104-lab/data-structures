#include <iostream>
using namespace std;

int main() {
    // Dynamic allocation for one character
    char* ch = new char;

    cout << "Enter a character: ";
    cin >> *ch;

    cout << "Stored character: " << *ch << endl;

    // Deallocate memory
    delete ch;
    ch =NULL;

    return 0;
}

