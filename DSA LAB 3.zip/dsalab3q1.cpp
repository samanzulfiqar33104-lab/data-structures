#include <iostream>
using namespace std;

struct Product {
    string name;
    int code;
    float price;
};

int main() {
    int n;
    cout << "Enter number of products: ";
    cin >> n;

    // Dynamic allocation
    Product* p = new Product[n];

    // Input
    for (int i = 0; i < n; i++) {
        cout << "\nEnter details of product " << i + 1 << endl;
        cout << "Name: ";
        cin >> p[i].name;
        cout << "Code: ";
        cin >> p[i].code;
        cout << "Price: ";
        cin >> p[i].price;
    }

    // Output
    cout << "\n--- Product List ---\n";
    for (int i = 0; i < n; i++) {
        cout << "Product " << i + 1 << ": "
             << p[i].name << ", "
             << p[i].code << ", "
             << p[i].price << endl;
    }

    // Free memory
    delete[] p;
    p = NULL;

    return 0;
}


